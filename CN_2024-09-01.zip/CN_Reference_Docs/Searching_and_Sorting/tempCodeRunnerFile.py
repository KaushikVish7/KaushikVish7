arr1.sort()
    arr2.sort()