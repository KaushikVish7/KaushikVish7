from sys import stdin

def sumOfTwoArrays(arr1, n, arr2, m, output) :
    idx1 = n-1
    idx2 = m-1
    idx3 = max(n, m)
    carry = 0

    while idx1 >= 0 and idx2 >= 0:
        sum = arr1[idx1] + arr2[idx2] + carry
        tens = sum // 10
        units = sum % 10
        output[idx3] = units
        carry = tens
        idx1 -= 1
        idx2 -= 1
        idx3 -= 1
    while idx1 >= 0:
        sum = arr1[idx1] + carry
        tens = sum // 10
        units = sum % 10
        output[idx3] = units
        carry = tens
        idx1 -= 1
        idx3 -= 1
    while idx2 >= 0:
        sum = arr2[idx2] + carry
        tens = sum // 10
        units = sum % 10
        output[idx3] = units
        carry = tens
        idx2 -= 1
        idx3 -= 1
    output[0] = carry

#Taking Input Using Fast I/O
def takeInput() :
    n = int(stdin.readline().rstrip())
    if n == 0 :
        return list(), 0
    
    arr = list(map(int, stdin.readline().rstrip().split(" ")))
    return arr, n


#to print the array/list
def printList(arr, n) :
    for i in range(n) :
        print(arr[i], end = " ")
    
    print()


#main
t = int(stdin.readline().rstrip())

while t > 0 :
    arr1, n = takeInput()
    arr2, m = takeInput()
    
    outputSize = (1 + max(n, m))
    output = outputSize * [0]
    
    sumOfTwoArrays(arr1, n, arr2, m, output)
    printList(output, outputSize)
    
    t -= 1