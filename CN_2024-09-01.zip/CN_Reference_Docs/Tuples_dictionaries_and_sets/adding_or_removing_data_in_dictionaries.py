'''
The data can be added into a dictionary in two ways:
1. using the []
2. using the update() method
'''

a = {1:2, 3:4, "list":[1, 23], "dict":{1:2}}
# adds a key "tuple" with value (1, 2, 3) into dictionary a
a["tuple"] = (1, 2, 3)
print(a)

# replaces the value of key 1 from 2 to 10
a[1] = 10
print(a)

'''
using the update() method, one can update the values of one dictionary into another. The key-value
pair will get added to the updated dictionary and the values of the common keys will be updated with
the values of the new dictionary
'''
b = {3:5, "the":4, 2:100} # key 3 is common in both dictionaries a and b
a.update(b)
print(a) # the value of key 3 in dictionary a is updated from 4 to 5 (value in dictionary b)

'''
Removing/deleting data in a dictionary can be done using:
1. pop() method which removes the KEY-VALUE pair of the key given within the () 
   and errors when the key given is not there in the dictionary
2. del operator deletes the dictionary itself or the KEY-VALUE pair of the key given within []
   and errors when the key given is not there in the dictionary
3. clear() method CLEARS/EMPTIES the entire dictionary. Returns an empty dictionary
'''
# to remove the key 1 from dictionary a
a.pop(1)
print(a)
# to remove the key "tuple" along with its value from the dictionary a
a.pop("tuple")
print(a)

# to delete a key "dict" from dictionary a
del a["dict"] # deletes the key "dict" along with its value from the dictionary a
print(a)

# to clear and empty the dictionary
a.clear()
print(a)

# to delete the ENTIRE dictionary itself
del a
# print(a) errors out because dictionary a has be permanently deleted from the system