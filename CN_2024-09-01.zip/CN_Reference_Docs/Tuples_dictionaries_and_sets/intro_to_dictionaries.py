'''
Dictionaries use the concept of key-value pair where the frequency of a certain key can be easily figured out using the 
value attribute. When compared with lists, "key" refers to the index of the list element and "value" refers to the element itself.
They are created using {}. Any type of key or any type of values can be given. They're MUTABLE. One can
make changes to both keys and values. Remove or add a key... etc.
'''
a = dict() # creates an empty dictionary
b = {} # another way to create an empty dictionary
print(a,  b)
print(type(a))

c = {"Kaushik": 5, "is": 4, "the": 3, 20000 :"man"} # Here "Kaushik" is the index and "5" is the value
print(c)
'''
One major advantage of dictionaries over lists is that, in the above dictionary, the last element has a "key" of 20000.
Which means that the value of "man" is at the 20000th index of a list, which would mean that the list must contain atleast
20001 elements which takes up a lot of memory space (the length of the list would be 20001 atleast).
But with dictionaries, it is not the case. If you check the length of the dictionary, it is still very small, as shown below:
'''
print(len(c))

# another way of creating a dictionary is to copy it from another dictionary
d = c.copy()
print(d)

# another way is to pass a list whose elements are in pairs and then, convert it into a dictionary
e = dict([("the", 3), ("a", 4)])
print(e)

'''
another way is to use "fromkeys" function where ONLY the keys are passed in a list and the values
are defaulted to "None" by Python as we're not passing any values. Only keys are passed. If you want 
to change the default value from None to something else, the "fromkeys" function takes another argument
after the list of keys, which is the value to be assigned other than the default value of None
'''
f = dict.fromkeys(["abc", 32, "efg", 64])
print(f) # the values are defaulted to "None"

g = dict.fromkeys(["abc", 55, "rrr", 99], "Kaushik")
print(g) # the values are now "Kaushik" for ALL the keys, instead of "None"