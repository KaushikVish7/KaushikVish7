'''
The data within dictionaries can be accessed using either [] or get().
Both of them return the same output in case the key is present in the dictionary. If the key is 
not present, [] will error out and get() won't error out and will give the default output "None"
'''

# accessing data in a dictionary using []
a = {1:2, 3:4, "list":[1, 23], "dict":{1:2}}
print(a)
print(a[1])
print(a[3])
print(a["list"])
# print(a["li"]) will error because there is no key with "li" in dictionary a. It has to be exact.

# another way of accessing data is by using the get() method
print(a.get(1)) # is the same as a[1]
print(a.get("list")) # is the same as a["list"]
print(a.get("li")) # WON'T error out and gives "None" as output by default, unlike []
print(a.get("li", "not present")) # will return "not present" instead of default value "None"

# if you want to get ALL the keys of a dictionary, use keys()
print(a.keys())

# if you want to get ALL the values of a dictionary, use values()
print(a.values())

# if you want to get ALL the key-value pairs, use items()
print(a.items())

'''
Looping on dictionaries
'''
# to print only the keys of a dictionary, there are 2 ways:
for key in a:
    print(key)

for i in a.keys():
    print(i)

# to print only the value of a dictionary, there are 2 ways:
for values in a:
    print(a[values])

for i in a.values():
    print(i)

# to print the key-value pairs of a dictionary
for key in a:
    print(key, a[key], end="\n")

# to check if a key exists in the dictionary or not, using in operator. It iterates ONLY through keys NOT values
print("list" in a)
print("li" in a)
print(2 in a) # will return False, as 2 is a value and NOT a key in dictionary a