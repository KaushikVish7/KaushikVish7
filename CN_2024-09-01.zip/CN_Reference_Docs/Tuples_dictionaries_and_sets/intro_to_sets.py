'''
Sets are basically an UNORDERED (no indexing) collection of data.
They store UNIQUE elements (no dupes are stored)
They're created using {} just like dictionaries. The only difference is that in sets, there is NO
key-value pair. There are only keys.

accessing elements of a set:
1. using in operator
2. using for loop
'''
s = {"apple", "abc", 23}
print(s)
print(type(s))

# to check if a set has a key or element:
print("apple" in s)
print("run" in s)

# iterating over a set
for v in s:
    print(v)

# checking the length of a set
print(len(s))

'''
modifying sets:
1. using add() method
2. using update() method
3. using remove() method - errors when the wrong parameter is passed
4. using discard() method - return the same set even when the wrong parameter is passed
5. using pop() method - removes any random element present in the set
6. using clear() method - empties the entire set
7. del operator - permanently deletes the entire set from the system
'''
# adding an element "temp" to set s
s.add("temp")
print(s)

# updating the set s with set t
t = {"abc", "ghi"} # note that "abc" is a common element and it is NOT duplicated in the new set
s.update(t)
print(s)

# deleting an element of a set using remove()
s.remove("temp")
# s.remove("rrr") errors out because "rrr" is not present in set s
print(s)

# deleting an element of a set using discard()
s.discard("ghi")
s.discard("rrr") # doesn't error out even if "rrr" isn't present in set s
print(s)

# deleting a random set element using pop() method
s.pop()
print(s)

# emptying the set
s.clear()
print(s)

# deleting the set
del s
# print(s) throws an error since the set is permanently deleted