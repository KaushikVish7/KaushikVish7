'''
Consider two sets a and b. Now, we'll be performing the following operations on them:
1. intersection - returns common elements between two sets
2. union - returns all the elements of both sets
3. difference - returns the elements after removing the elements of 2nd set from 1st set or vice-versa
4. symmetric_difference - returns union minus intersection of two sets
5. intersection_update - updates the set with the intersection of two sets
6. difference_update - updates the set with the difference of two sets
7. symmetric_difference_update - updates the set with symmetric difference of both sets
8. issubset() - checks if a set is a subset of another set
9. issuperset() - checks if a set is a superset (contains another set) of another set
10. isdisjoint() - checks if two sets have anything in common, any intersection
'''

a = {1, 2, 3, 4}
b = {3, 4, 5, 6}

# intersection of sets
print(a.intersection(b))
print(b.intersection(a))
print(a.intersection(a))

# union of sets
print(a.union(b))
print(b.union(a))
print(a.union(a))

# difference of sets
print(a.difference(b))
print(b.difference(a))
print(a.difference(a))

# symmetric difference of sets
print(a.symmetric_difference(b))
print(b.symmetric_difference(a))

# intersection_update
# a.intersection_update(b)
# print(a)

# # difference_update
# a.difference_update(b)
# print(a)

# symmetric_difference_update
# a.symmetric_difference_update(b)
# print(a)

# issubset()
c = {3, 4}
print(a.issubset(b))
print(a.issubset(c))
print(c.issubset(a))
print(c.issubset(b))

# issuperset()
print(a.issuperset(c))
print(b.issuperset(c))
print(a.issuperset(b))

# disjoint()
print(a.isdisjoint(c))
print(a.isdisjoint({7, 8, 9}))