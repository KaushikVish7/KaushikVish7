# Tuples are different from lists. They are characterized by () while lists are characterized by [] they're IMMUTABLE
'''
a = (1,2,3)
a[0] = 6
print(a)
'''
# tuples are HETEROGENEOUS i.e they can store elements of different data types simultaneously
b = (1,"a",.67,98000)
print(b)
c = tuple() # creates an empty tuple
print(c)
# Sometimes, even if you don't enclose the elements in (), Python assumes that it is a tuple by default. For eg,
s = (1,2,3,4,5,6) # this is a tuple
t = 7,8,9,10,11,12 # this is ALSO a tuple
print(t, type(t))

# In case of lists, tuples and strings we're able to use indexing, slicing because they're ORDERED. These don't apply to sets.
print(t[0])
print(t[1])
print(t[-1])
print(t[-2])
print(t[2:])
print(t[::-1])

# two tuples can be concatenated
u = s + t 
print(u)

# a tuple of tuples can be created
v = (s, t)
print(v)