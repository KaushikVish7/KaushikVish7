def print_k_freq_words(sentence, k):
    words = sentence.split()
    print(words)

    d = {}
    for w in words:
        if w in d:
            d[w] += 1
        else:
            d[w] = 1
        # d[w] = d.get(w, 0) + 1 also works like the above lines of code, and is more concise but less easier to understand
    print(d)

    for w in d:
        if d[w] == k:
            print(w, end=" ")

sentence = input("Enter the sentence: ")
k = int(input("Enter the word frequency: "))
print_k_freq_words(sentence, k)