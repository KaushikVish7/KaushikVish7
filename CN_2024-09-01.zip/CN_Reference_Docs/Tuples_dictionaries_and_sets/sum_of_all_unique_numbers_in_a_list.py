def sum_unique(li):
    s = set() # if s = {} then s would be of type dict, not set. Hence s = set() is the right way
    for i in li:
        s.add(i) # it would error out if we had initialized s = {} instead of s = set() as s would be considered a dictionary and add() won't work on dictionaries
    sum = 0
    for i in s:
        sum += i
    return sum

print("Enter the list numbers:")
li = [int(x) for x in input().split()]
res = sum_unique(li)
print("The sum of unique numbers is:", res)