'''
fixed length input, where the number of input arguments for a function is fixed, even if some of the arguments are defaulted
'''
def sum(a, b, c=0, d=0, e=0):
    return a + b + c + d + e

print(sum(3, 4, 1, 2, 5))

'''
variable length input can be implemented using a *, where 
some arguments are fixed i.e it is mandatory for the user to give these values in the input
(2 in the below example) and the rest are optional
'''
def sum2(a, b, *more):
    print(a)
    print(b)
    print(type(more))
    res = a + b
    for i in more:
        res += i
    return res

print(sum2(2, 3, 4, 5))

'''
variable length output, i.e the function can return more than one value at a time
'''
def sum_diff(a, b):
    return a + b, a - b

d = sum_diff(3, 4)
print(d)

d, e = sum_diff(3, 4)
print(d)
print(e)

'''
The below code encompasses all the concepts and examples we looked at
'''
def sum_multiply(a,b,*more):
    sum_value = a+b
    m_value = a*b
    for i in more:
        sum_value += i
        m_value*=i
    return sum_value,m_value
s_m = sum_multiply(2,3,4)
print(s_m)