a = (1,2,3)
b = 4,5
# the loops can be run as usual on tuples as well
for i in a:
    print(i)

# check if an element exists in a tuple or not - checking for membership
print(1 in a)
print(22 in a)

# check for length of a tuple
print(len(b))

# concatenante two tuples
c = a + b
print(c)

# a tuple of tuples
d = (a, b)
print(d)

# repeat a tuple - repetition
print(a * 3)

# minimum and maximum element in a tuple
print(min(a))
print(max(a))
'''
e = (1,"a",.67,98000,(2,3))
print(min(e)) throws an error
print(max(e)) throws an error
the min and max functions won't work on the above tuple e because it is heterogeneous. 
They can't compare elements of different data types at once. The data types have to be the SAME for them to work
'''

# list to tuple
l = [1,2,3,4]
t = tuple(l) # converts the list to tuple
print(t)