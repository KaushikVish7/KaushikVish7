def count_in_string(str1):
    v, c, d, s = 0, 0, 0, 0
    for l in str1:
        if (l >= "a" and l <= "z") or (l >= "A" and l <= "Z"): # checks for letters or alphabets
            l = l.lower() # converts all letters to lowercase for easy comparison
            if l == "a" or l == "e" or l == "i" or l == "o" or l == "u": # checks for vowels
                v += 1 # increments vowel count
            else:
                c += 1 # increments consonant count
        elif l >= "0" and l <= "9": # checks for digits
            d += 1 # increments digit count
        else:
            s += 1 # increments special character count

    return v, c, d, s

str1 = input("Enter the test string: ")
v, c, d, s = count_in_string(str1)
print("Vowels:", v)
print("Consonants:", c)
print("Digits:", d)
print("Special characters:", s)