string1 = str(input("Enter the string:"))
string2 = string1[::-1]
if string1 == string2:
    print(True)
else:
    print(False)