a = "Kaushik"
print(a[:])
print(a[1:])
print(a[:4])
print(a[1:10]) # This won't throw error even if the end index is out of range, it will print the entire list from 1st index
print(a[1:4])
print(a[1:4:2])
print(a[4::-1]) # Positive slicing, negative step, goes upto index 0
print(a[4:1:-1]) # Positive slicing, negative step, goes upto index 2
print(a[:2:-1]) # Goes from last index upto index 3
print(a[5:1:-2]) # Starts from 5th index, goes upto 2nd index in negative steps of 2
print(a[-1], a[-2]) # Negative indexing, going from the last element
print(a[-5:-3:1]) # Negative slicing, positive step
print(a[-3:-5:-1]) # Negative slicing, negative step
