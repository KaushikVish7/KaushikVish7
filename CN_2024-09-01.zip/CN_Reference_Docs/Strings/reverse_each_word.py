# Input: "Welcome to Coding Ninjas"
# Output: "emocleW ot gnidoC sajniN"

from sys import stdin

def reverseEachWord(string):
    reversed_string = ""
    words = string.split()
    reversed_words = [word[::-1] for word in words] # takes every word and reverses it individually into a list
    reversed_string = " ".join(reversed_words) # joins all the words, which is a list to the new string
    return reversed_string
#main
string = stdin.readline().strip()
ans = reverseEachWord(string)
print(ans)