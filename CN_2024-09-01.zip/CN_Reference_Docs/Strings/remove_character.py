# If input is "aabccbaa" and we want to remove "a", output should be "bccb"
from sys import stdin

def removeAllOccurrencesOfChar(string, ch) :
    size = len(string)
    new_str = ""
    for i in range(size):
        if string[i] != ch:
            new_str += string[i]
    return new_str

#main
string = stdin.readline().strip()
ch = stdin.readline().strip()[0]

ans = removeAllOccurrencesOfChar(string, ch)

print(ans)