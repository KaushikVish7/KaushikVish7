'''The goal is to return the character that occurs the most in a given string. There are two cases:
1. Input: "abdefgbabfba" Output: b (as "b" appears 4 times which is the highest occurrace)
2. Input: "xy" Output: "x" (if 2 characters have same frequency of occurrace, return the 1st character)'''

from sys import stdin
def highestOccuringChar(string) :
    freq_arr = [0] * 26
    max_freq = 0
    size = len(string)
    for i in range(size): # Accounts for condition 1
        freq_arr[ord(string[i]) - ord("a")] += 1
        max_freq = max(max_freq, freq_arr[ord(string[i]) - ord("a")])
    for i in range(size): # Accounts for condition 2
        if freq_arr[ord(string[i]) - ord("a")] == max_freq:
            return string[i]
#main
string = stdin.readline().strip()
ans = highestOccuringChar(string)

print(ans)