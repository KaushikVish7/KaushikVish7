string = "Hello World"
# Code to calculate how many times "l" appears in this string:
count = 0
for letter in string:
    if letter == "l":
        count += 1
print("'l' appears", count, "times in", string)

# Code to iterate on each index of the string:
for i in range(len(string)):  # Using index as an integer type, so the range will be upto string length
    print(string[i], end=" ")
print()
for l in string:            # Using index as a string type, so there is no need for range, the string can be directly iterated
    print(l, end=" ")
print()

# in and notin operations on a string
# in and notin check for a sub-string in a string.
# starting from any character, a continuous part of a string is called a sub-string
if "Heo" in string:
    print("Yes it is a sub-string") # Hel is a substring, but hel or Heo is not
else:
    print("No it is not a sub-string")