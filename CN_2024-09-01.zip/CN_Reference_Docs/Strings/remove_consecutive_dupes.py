# If the input is "aaaa" the output should be "a". If "aabbcca" then "abca" should be the output
from sys import stdin

def removeConsecutiveDuplicates(string):
    size = len(string)
    new_str = ""
    if size == 0:
        return new_str
    else:
        prev_char = string[0]
        new_str += prev_char  # We directly add the 1st letter of the string as it is unique and scan from 2nd letter to size-1
        for i in range(1, size):
            if string[i] == prev_char:
                continue
            else:
                new_str += string[i]
                prev_char = string[i]
    return new_str
#main
string = stdin.readline().strip()
ans = removeConsecutiveDuplicates(string)
print(ans)