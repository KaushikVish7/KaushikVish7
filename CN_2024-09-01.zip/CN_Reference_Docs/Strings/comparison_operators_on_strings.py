# Major comparison operators used on strings are:
# ==
# >=, >
# <=, <
# !=

a = "Kaushik" == "Kaushik" # Comparing a string with itself, the output will be True
print(a)
b = "Laushik" >= "Kaushik" # L has a greater ASCII value than K, hence the output will be True
print(b)
c = "Kbushik" >= "Kaushik" # The 2nd letter b has greater ASCII value than a, hence the output will be True
print(c)
d = "kaushik" >= "Kaushik" # k is compared with K, output is True as k has greater ASCII value than K
print(d)
e = "Kau" >= "Kaushik" # since the letters are ditto, the string with greater length will have greater ASCII value, output will be False
print(e)
f = "Kaushik" > "Kaushik" # both strings are ditto, one can't be greater than the other, output will be False
print(f)
g = "Kaushik" < "Kaushik" # both strings are ditto, one can't be lesser than the other, output will be False
print(g)
h = "Kaushik" != "Kaushik" # both strings are ditto, output will be False
print(h)