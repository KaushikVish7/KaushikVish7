a = "Kaushik"
print(a)
b = 'Kaushik'
print(b)
c = '''Kaushik'''
print(id(a)) 
print(id(b))
print(id(c)) # The ids are the same since all the variables are pointing to the same memory location (same string)
# d = "My
# name is Kaushik" Double quotes support only single-line strings. Not multi-line strings.
d = '''My
name is Kaushik''' # Triple quotes support multi-line strings.
print(d)
print(a[0], b[1], c[2], a[-1], a[-2]) # indexing concept in strings is same as that of lists.
print(d[2]) # in the string d which is a multi-line string, the element at 2nd index is next line or \n, which is printed in the output.
# a[0] = "R" This line will give error because STRINGS ARE IMMUTABLE.