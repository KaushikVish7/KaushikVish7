a = "red"
a += "_blue" # Concatenating string a with another string
a += "_green" + "_yellow" # Concatenating string a with multiple strings
print(a)
print(id(a))
a += "_orange"
print(a)
print(id(a))
b = "blue"
print(b)
print(id(b))
b *= 3 # Another way of concatenating the same string with itself, multiple times
# b += 3 will throw and error because we can't append an integer to a string. There is a data type mismatch.
b += str(3) # Converting an integer to string so that it can be concatenated.
print(b)
print(id(b))