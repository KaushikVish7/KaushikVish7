def replace_chars(string, char1, char2):
    new_str = ""
    for l in string:
        if l == char1:
            new_str += char2
        else:
            new_str += l
    
    return new_str

string1 = input("Enter a string: ")
char1 = input("Enter the character to be replaced: ")
char2 = input("Enter the character to replace it with: ")
res = replace_chars(string1, char1, char2)
print(res)