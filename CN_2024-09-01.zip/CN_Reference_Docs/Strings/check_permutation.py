'''For example, "abcd" and "dcba" are string permutations and "abc","cbd" are not.
Which means that the letters and their count in both the strings are the same but the order is different'''

from sys import stdin

def isPermutation(string1, string2):
    all_alphabets = [0] * 26 # a list of 26 zeroes
# ord() returns the integer representation of a character value. For eg, ord('a') will be 97
    for i in range(len(string1)):
        all_alphabets[ord(string1[i]) - ord('a')] += 1
# The above line calculates the difference between the integer values of the characters present in the ith index of string1 and
#the integer value of 'a' and adds 1 to that index of the all_alphabets array
    for j in range(len(string2)):
        all_alphabets[ord(string2[j]) - ord('a')] -= 1
    flag = True
# The loop checks for any values other than 0 in the all_alphabets array and breaks out if it finds one
    for k in range(len(all_alphabets)):
        if all_alphabets[k] != 0:
            flag = False
            break
    
    return flag

# Main
string1 = stdin.readline().strip()
string2 = stdin.readline().strip()

ans = isPermutation(string1, string2)

if ans:
    print('true')
else:
    print('false')
