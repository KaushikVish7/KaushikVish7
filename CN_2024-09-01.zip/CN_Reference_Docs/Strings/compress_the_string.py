'''Given a string, compress it by replacing the consecutive characters with their frequency of occurrace.
The compression takes place only when the running (continuous) frequency is more than 1.
Eg: Input: "xxxxx" Output: "x5"
    Input: "aaabbccdsa" Output: "a3b2c2dsa" '''

from sys import stdin,setrecursionlimit
setrecursionlimit(10**7)

def getCompressedString(input) :
    new_str = ""
    curr_char = input[0] # 1st character is assigned, so that the output string is not empty
    curr_len = 1 # Since atleast one character is there, the length displayed should be 1
    for i in range(1, len(input)): # Scans from the 2nd character of the string to the last character
        if input[i] == curr_char: # Increments the length of the current character until it's running frequency
            curr_len += 1
        else:
            new_str += curr_char # Once another character is encountered, append the current char to the the main string
            if curr_len != 1: # Appends the curr_length only if it is greater than 1. If not, curr_length is not appended
                new_str += str(curr_len) # Integer is converted to string so that it can be appended to another string
            curr_char = input[i] # curr_char becomes the next character in the string
            curr_len = 1 # since curr_char is now changed, curr_length is initialized back to 1

    new_str += curr_char # This accounts for the first character of the string, that is if the string contains only 1 character
    if curr_len != 1:
        new_str += str(curr_len)

    return new_str

# Main.
string = stdin.readline().strip()
ans = getCompressedString(string)
print(ans)