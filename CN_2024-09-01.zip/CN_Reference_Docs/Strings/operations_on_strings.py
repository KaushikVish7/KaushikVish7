# split function
string = "My,name,is,Kaushik"
print(string.split(",")) # the delimiter for split by default, is space
print(string.split(",", 1)) # splits the string into one item
print(string.split(",", 2)) # splits the string into two items

# replace funtion
a = "My name is Kaushik Kaushik Kaushik"
print(a.replace("Kaushik", "Sunaina")) # replaces the 1st argument with the 2nd argument
print(a.replace("Kaushik", "Sunaina", 2)) # Replaces only 2 "Kaushik" with "Sunaina"
print(a.replace("Rohan", "Sunaina")) # nothing will be replaced and no error will occur. The string will remain the same and is printed

# find function
b = "My name is Kaushik Kaushik"
print(b.find("na")) # returns the index of the character or the 1st character of the substring
print(b.find("Na")) # returns -1 as it doesn't exist in the main string
print(b.find("a")) # returns the index of the 1st "a" it encounters in the main string
print(b.find("Kau", 16, 21)) # checks for the substring from index 16 to 19 of the main string and returns the corresponding index

# lower and upper functions
c = "My name is Kaushik"
print(c.lower()) # converts all the characters to lowercase
print(c.upper()) # converts all the characters to uppercase

# startswith function
d = "My name is Kaushik"
print(d.startswith("is Kau")) # checks and returns a boolean value
print(d.startswith("My na"))
print(d.startswith("is Kau", 8, 30))
