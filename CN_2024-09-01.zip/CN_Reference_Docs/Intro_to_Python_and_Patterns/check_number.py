# Read input as sepcified in the question
# Print output as specified in the question
n = int(input())

if n==0:
    print("Zero")
elif n>0:
    print("Positive")
else:
    print("Negative")