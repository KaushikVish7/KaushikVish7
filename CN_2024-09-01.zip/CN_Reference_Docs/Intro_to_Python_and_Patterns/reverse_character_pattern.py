from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.

N = int(input())
i = 1
l = N

while i <= N:
    j = 1
    end_char = chr(ord('A') + l - 1)
    l -= 1
    while j <= i:
        k = chr(ord(end_char) + j - 1)
        print(k, end="")
        j += 1
    print()
    i += 1