from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.
n = int(input())
i = 1
k = n

while i <= n:
    j = 1
    while j <= k:
        print(j, end="")
        j += 1
    print()
    k -= 1
    i += 1