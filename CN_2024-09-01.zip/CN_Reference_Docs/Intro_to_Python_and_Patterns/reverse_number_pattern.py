## Read input as specified in the question
## Print the required output in given format
n = int(input())
i = 1

while i <= n:
    j = 1
    k = i
    while j <= i:
        print(k, end="")
        k -= 1
        j += 1
    print()
    i += 1