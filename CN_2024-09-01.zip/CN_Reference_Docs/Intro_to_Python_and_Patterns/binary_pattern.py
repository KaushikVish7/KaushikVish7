from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.
n = int(input())

if n%2 == 0:
    for i in range(n, 0, -1):
        if i%2 == 0:
            for j in range(1, i+1):
                print("1", end="")
            print()
        else:
            for k in range(1, i+1):
                print("0", end="")
            print()

else:
    for i in range(n, 0, -1):
        if i%2 != 0:
            for l in range(1, i+1):
                print("1", end="")
            print()
        else:
            for m in range(1, i+1):
                print("0", end="")
            print()
