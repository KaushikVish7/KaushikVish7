from os import *
from sys import *
from collections import *
from math import *

n = int(input())
start = 1
end = 2*n + 1
mid = n+1
i = 1

while i <= n:
    j = 1
    while j <= 2*n+1:
        if j == start or j == mid or j == end:
            print("*", end="")
        else:
            print("0", end="")
        j += 1
    print()
    start += 1
    end -= 1
    i += 1
        