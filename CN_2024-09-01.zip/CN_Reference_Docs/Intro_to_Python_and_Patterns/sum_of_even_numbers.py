## Read input as specified in the question.
## Print output as specified in the question.
N = int(input())
i=1
sum=0

while i<=N:
    if i%2 == 0:
        sum += i

    i += 1

print(sum)