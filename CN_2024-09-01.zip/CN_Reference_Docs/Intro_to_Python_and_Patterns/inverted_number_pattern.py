## Read input as specified in the question
## Print the required output in given format

n = int(input())
i = 1
k = n

while i <= n:
    j = 1
    while j <= k:
        print(k, end="")
        j += 1
    print()
    k -= 1
    i += 1  