from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.
n = int(input())
i = 1

while i <= n:
    spaces = 1
    while spaces < i:
        print(" ", end="")
        spaces += 1
    num = i
    while num <= n:
        print(num, end="")
        num += 1
    print()
    i += 1

k = 1
while k < n:
    spaces = 1
    while spaces < n-k:
        print(" ", end="")
        spaces += 1
    j = k+1
    while j > 0:
        print(n-j+1, end="")
        j -= 1
    print()
    k += 1