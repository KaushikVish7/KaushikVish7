# Write your code here
a = int(input())
b = int(input())
c = int(input())

d = b - a 

print(d)