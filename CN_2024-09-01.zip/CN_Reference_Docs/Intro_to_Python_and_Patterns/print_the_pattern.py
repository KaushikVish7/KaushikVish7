'''If input is 4, the output should be:
    1 2 3 4
    9 10 11 12
    13 14 15 16
    5 6 7 8
'''

# Take input for the size of the matrix
n = int(input()) 

# Initialize the starting value
startValue = 1

# Outer loop for each row
for i in range(1, n+1): 
    # Inner loop for each column
    for j in range(startValue, startValue + n):
        # Print the current value of j with a space
        print(j, end=" ")

    # Move to the next line after each row
    print()

    # Update startValue based on the position of the current row
    if i == (n+1) // 2:
        # If the current row is the middle row
        if (n % 2) != 0:
            startValue = n * (n - 2) + 1
        else:
            startValue = n * (n - 1) + 1
    elif i > (n+1) // 2:
        # If the current row is beyond the middle row
        startValue = startValue - 2 * n
    else:
        # If the current row is before the middle row
        startValue = startValue + 2 * n
