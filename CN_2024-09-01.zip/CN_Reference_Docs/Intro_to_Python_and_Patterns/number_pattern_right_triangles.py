n = int(input())
i = 1

while i <= n:
    j = 1
    while j <= i:
        print(j, end="")
        j += 1
    spaces = 1
    while spaces <= 2*n - 2*i:
        print(" ", end="")
        spaces += 1
    dec = i
    while dec >= 1:
        print(dec, end="")
        dec -= 1
    print()
    i += 1