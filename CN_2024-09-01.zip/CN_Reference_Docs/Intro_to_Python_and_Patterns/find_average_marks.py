# Read input as sepcified in the question
# Print output as specified in the question
t1 = int(input())
t2 = int(input())
t3 = int(input())

avg = (t1 + t2 + t3) / 3

print(avg)