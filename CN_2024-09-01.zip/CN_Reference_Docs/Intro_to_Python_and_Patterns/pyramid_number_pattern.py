from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.
n = int(input())
i = 1

while i <= n:
    spaces = 1
    while spaces <= n-i:
        print(" ", end="")
        spaces += 1
    dec = i
    while dec >= 1:
        print(dec, end="")
        dec -= 1
    inc = 2
    while inc <= i:
        print(inc, end="")
        inc += 1
    print()
    i += 1