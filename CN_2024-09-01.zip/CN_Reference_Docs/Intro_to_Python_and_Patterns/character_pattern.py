## Read input as specified in the question
## Print the required output in given format
n = int(input())
i = 1

while i <= n:
    j = 1
    start_char = chr(ord('A') + i - 1)
    while j <= i:
        k = chr(ord(start_char) + j - 1)
        print(k, end="")
        j += 1
    print()
    i += 1