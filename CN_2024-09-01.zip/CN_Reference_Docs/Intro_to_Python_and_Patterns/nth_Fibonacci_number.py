from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.
N = float(input())
a = 0
b = 1
i = 0

while i < N:
    c = a + b
    a = b
    b = c
    i += 1

print(a)