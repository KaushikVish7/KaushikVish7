#Write Your Code Here
N = int(input())
sum = 0

while N != 0:
    rem = N % 10
    sum = (sum * 10) + rem
    N = N // 10

print(sum)
