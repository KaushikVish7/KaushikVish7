from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.

n = int(input())
i = 1

print("1")
while i <= n-1:
    print(i, end="")
    j = 1
    while j <= i-1:
        print("0", end="")
        j += 1
    print(i, end="")
    print()
    i += 1