n=int(input())  
# taking n as a input 
## write your code !!

temp = n
rev = 0

while n > 0:
    rem = n % 10
    rev = (rev * 10) + rem
    n = n // 10

if temp == rev:
    print("true")

else:
    print("false")