## Read input as specified in the question.
## Print output as specified in the question.
n = int(input())
n1 = (n+1)//2
n2 = n1-1
i = 1

while i <= n1:
    spaces = 1
    while spaces <= i-1:
        print(" ", end="")
        spaces += 1
    stars = 1
    while stars <= i:
        print("*", end=" ")
        stars += 1
    print()
    i += 1

j = 1

while j <= n2:
    spaces = 1
    while spaces <= n2-j:
        print(" ", end="")
        spaces += 1
    stars = 1
    while stars <= (n2 - j) + 1:
        print("*", end=" ")
        stars += 1
    print()
    j += 1