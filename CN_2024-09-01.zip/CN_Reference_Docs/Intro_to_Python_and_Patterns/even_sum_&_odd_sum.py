## Note : For printing multiple values in one line, put them inside print separated by space.
## You can follow this syntax for printing values of two variables val1 and val2 separaetd by space -
## print(val1, " ", val2)

n = int(input())
odd_sum = 0
even_sum = 0

while n != 0:
    rem = n % 10
    if rem % 2 == 0:
        even_sum += rem
    else:
        odd_sum += rem
    n = n // 10

print(even_sum, " ", odd_sum)
