from math import *
from collections import *
from sys import *
from os import *

## Read input as specified in the question.
## Print output as specified in the question.
n = int(input())

i = 1
spaces = n//2
while i <= n:
    print(" " * spaces + "*" * i)
    spaces -= 1
    i += 2

i = n - 2
spaces = 1
while i >= 1:
    print(" " * spaces + "*" * i)
    spaces += 1
    i -= 2