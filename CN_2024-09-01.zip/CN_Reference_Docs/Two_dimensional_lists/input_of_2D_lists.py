# Taking input into a 2D list where the column size is fixed
print("Enter the dimensions (n X m) of the 2D list:")
input_dimensions = input().split()
n, m = int(input_dimensions[0]), int(input_dimensions[1])
print("Enter the elements into the list:")
li = [[int(j) for j in input().split()] for i in range(n)]
print(li)

# Taking input into a 2D list where the column size is not fixed (Jagged list)
print("Enter the number of rows of the jagged list:")
n = int(input())
li = [[int(j) for j in input().split()] for i in range(n)]
print(li)