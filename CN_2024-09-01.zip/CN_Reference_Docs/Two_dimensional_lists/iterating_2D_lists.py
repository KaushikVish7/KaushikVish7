''' This code is used to iterate a given 2D list and print the same '''
li = [[1,2,3,4],[5,6,7,8],[9,10,11,12]]
n = 3
m = 4
for i in range(n):
    for j in range(m):
        print(li[i][j], end=" ")
    print()

# But the above code won't work on Jagged lists, where the number of columns is not constant. In that case:
li = [[1,2,3,4],[5,6],[9,10,11]]
for row in li:
    for ele in row:
        print(ele, end=" ")
    print()
# The above code not only works on Jagged lists, but also on normal 2D lists! It is a universal code to iterate over 2D lists

# join function on iterables, that is lists and strings:
print("ab".join("xy"))
print("ab".join("abcd"))
print("ab".join(['1','2','3','4'])) # the elements of the list should be of type:str for the join function to work, because string and integer can't be concatenated

# The concept of join() can be used to append " " with every element of the list as shown below:
li = [[1,2,3,4],[5,6],[9,10,11]]
for row in li:
    output = " ". join([str(ele) for ele in row])
    print(output)
