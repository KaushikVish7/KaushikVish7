'''Jagged lists are basically 2D lists (n X m, where n = m), where the column size are NOT SAME. That means, every row need not have the same
number of columns. These lists are not squares (n X m, where n != m).'''
li = [[1,2,3,4],[5,6,7],[8,9],[10]]
print(li) # Here, li is a jagged list (n X m, where n != m)
print(li[1])
print(li[2])
# print(li[2][3]) will give error as list index out of range
print(li[0][3])