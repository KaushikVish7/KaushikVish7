''' Suppose the user passes all the list elements (which are space separated) in one single line, in that case, how do 
you split the elements such that it matches with n*m dimension? This can be done using a simple formula:
                            (i, j) = m*i + j
where i = ith element of the 2D list
      j = jth element of the 2D list
      m = the number of rows specified for the 2D list
      n = the number of columns specified for the 2D list '''

print("Enter the dimensions of the 2D list:")
str = input().split()
n, m = int(str[0]), int(str[1])
print("Enter the elements:")
b = input().split()
arr = [[int(b[m * i + j]) for j in range(m)] for i in range(n)]
print(arr)

# In case all the inputs: n, m and the list elements are given in one single line, then:
print("Enter the dimensions of the 2D list:")
str = input().split()
n, m = int(str[0]), int(str[1]) # The first 2 inputs are taken as n and m
print("Enter the elements:")
b = str[2:] # The rest of the elements of input from index 2 are taken as string b (elements of the 2D list)
arr = [[int(b[m * i + j]) for j in range(m)] for i in range(n)]
print(arr)