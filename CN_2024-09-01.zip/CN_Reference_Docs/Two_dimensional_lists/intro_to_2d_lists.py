# Only a list of list can be called a 2D list or 2D array like for eg, below list:
li = [[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]] # It is a 2D list
print(li[2][2])
print(li[2][3])
# print(li[5][5]) Throws "list index out of range" error
li[1][3] = 40
print(li)

# Storing of 2D Lists
li = [[1,2,3,4],[5,6,7,8]] # This 2D list will have 2 rows and 4 columns
print(type(li[0])) # Even an individual element of a list is a list in itself
li[0][1] = 4
print(li)
print(id(li)) # id of the main list
print(id(li[0])) # id of the 1st sublist
print(id(li[1])) # id of the 2nd sublist
li[1] = "Kaushik" # Let us change li[i] address reference by changing its value
print(li) # It is NOT a 2D list as it is not a list of list, it is a list of a list and a string
print(id(li)) # This address reference remains the same
print(id(li[0])) # This address reference remains the same
print(id(li[1])) # Now the id of 2nd sublist is different because now it is referring to a different memory address