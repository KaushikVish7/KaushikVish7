''' Return the index of the column with the largest sum in the 2D array. For eg, consider the below 2D list:
                2 3 4
                5 6 7
                8 9 10
    col_sum:   15 18 21
so the largest column sum is 21 which belongs to 3rd column. So the code should return its index which is 2'''
def largest_column_sum(li):
    n = len(li) # The row count will be the length of the main 2D list
    m = len(li[0]) # The column count will be the length of the 1st row of the list. The column length is constant. It isn't a Jagged list
    max_col_sum = -1 # Just initializing a value it can be 0 also
    max_col_index = -1 # Just initializing a value to index
    for j in range(m):
        curr_col_sum = 0
        for i in range(n):
            curr_col_sum += li[i][j]
        if curr_col_sum > max_col_sum:
            max_col_sum = curr_col_sum
            max_col_index = j
    return max_col_sum, max_col_index

li = [[1,2,3,4],[8,7,6,5],[9,10,11,12]]
# li[2][3] = 7
lar_sum, lar_col_index = largest_column_sum(li)
print("Largest column sum: ", lar_sum)
print("Index of column with largest sum: ", lar_col_index)