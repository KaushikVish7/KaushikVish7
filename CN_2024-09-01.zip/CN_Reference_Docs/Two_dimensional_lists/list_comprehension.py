li_1 = [1,2,3,4]
new_li = []
for ele in li_1:
    new_li.append(ele**2)
print(li_1)
print(new_li)

# The above code can be written in 1 line using the power of comprehension as shown below:
print("Enter the list elements to be squared:")
li_2 = [int(x) for x in input().split()]
li_square = [(ele**2) for ele in li_2]
print(li_square)

# The syntax of list comprehension is: [output for expression condition] for example,
print("Enter the elements and only multiples of 3 will be cubed and displayed:")
li_3 = [int(x) for x in input().split()]
li_cube = [ele**3 for ele in li_3 if ele % 3 == 0]
print(li_cube)

# To append elements which are a muliple of 2 and 3:
print("Enter the list elements and only multiples of 2 and 3 will be returned:")
li_4 = [int(x) for x in input().split()]
li_2_3 = [ele for ele in li_4 if ele%2 == 0 if ele%3 == 0] # any number of "if" can be written within the []
# li_2_3 = [ele for ele in li_4 if ele%2 == 0 and ele%3 == 0] would also give the same result
print(li_2_3)

# Using multiple for loops within the list comprehension:
li_1 = [1,2,3,4,5]
li_2 = [2,4,6,7]
# to get the common between the above 2 lists, we can write
li_intersection = []
for ele in li_1:
    for ele_2 in li_2:
        if ele == ele_2:
            li_intersection.append(ele)
print(li_intersection)
# The same lines of code can be simplified to one line using list comprehension like this:
li_intersection = [ele for ele in li_1 for ele_2 in li_2 if ele == ele_2]
print(li_intersection)

# Using if-else condition:
print("Enter the list elements:")
li = [int(x) for x in input().split()]
li_intersection = [ele**2 if ele%2==0 else ele for ele in li]
''' The only caveat here is that if-else comes BEFORE the for loop expression, and not after it'''
print(li_intersection)

# Printing a string and characters of a string:
s = "Kaushik"
li = [s for ele in s] # Prints "Kaushik" 7 times, as the string contains 7 characters
print(li)
li = [ele for ele in s] # Prints every letter of the string in a list

# Generating a list of lists, a 2D list:
print("Enter a list of names:")
name_list = [x for x in input().split()]
li_2D = [[letter for letter in name] for name in name_list]
print(li_2D)