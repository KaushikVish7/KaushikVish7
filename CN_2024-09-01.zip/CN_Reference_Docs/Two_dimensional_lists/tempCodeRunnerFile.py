 # for j in range(mCols):
    #     col_sum = 0
    #     for i in range(nRows):
    #         col_sum += arr[i][j]
    #     if col_sum > max:
    #         max = col_sum
    #         col_idx = j
    # if row_sum == col_sum:
    #     print("row", row_idx, row_sum)
    # elif row_sum > col_sum:
    #     print("row", row_idx, row_sum)
    # else:
    #     print("column", col_idx, col_sum)