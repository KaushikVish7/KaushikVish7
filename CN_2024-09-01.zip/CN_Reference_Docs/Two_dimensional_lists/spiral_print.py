'''
For a given two-dimensional integer array/list of size (N x M), print it in a spiral form.
That is, you need to print in the order followed for every iteration:
a. First row(left to right)
b. Last column(top to bottom)
c. Last row(right to left)
d. First column(bottom to top), excluding the top-most element of the current column.
Mind that every element will be printed only once.
'''
from sys import stdin

def spiralPrint(mat, nRows, mCols):
    if nRows == 0 or mCols == 0:
        return
    else:
        elements = nRows * mCols
        row_low_lim = 0
        row_up_lim = nRows - 1
        col_low_lim = 0
        col_up_lim = mCols - 1

        while elements > 0:
            for i in range(col_low_lim, col_up_lim+1):  # left to right
                print(mat[row_low_lim][i], end=" ")
                elements -= 1
        
            row_low_lim += 1

            for i in range(row_low_lim, row_up_lim+1):  # top to bottom
                print(mat[i][col_up_lim], end=" ")
                elements -= 1

            col_up_lim -= 1

            # Check if the last row has been printed
            if elements > 0:
                for i in range(col_up_lim, col_low_lim-1, -1):  # right to left
                    print(mat[row_up_lim][i], end=" ")
                    elements -= 1

                row_up_lim -= 1

            # Check if the last column has been printed
            if elements > 0:
                for i in range(row_up_lim, row_low_lim-1, -1):  # bottom to top
                    print(mat[i][col_low_lim], end=" ")
                    elements -= 1

                col_low_lim += 1

#Taking Input Using Fast I/O
def take2DInput() :
    li = stdin.readline().rstrip().split(" ")
    nRows = int(li[0])
    mCols = int(li[1])
    
    if nRows == 0 :
        return list(), 0, 0
    
    mat = [list(map(int, input().strip().split(" "))) for row in range(nRows)]
    return mat, nRows, mCols


#main
t = int(stdin.readline().rstrip())

while t > 0 :

    mat, nRows, mCols = take2DInput()
    spiralPrint(mat, nRows, mCols)
    print()

    t -= 1