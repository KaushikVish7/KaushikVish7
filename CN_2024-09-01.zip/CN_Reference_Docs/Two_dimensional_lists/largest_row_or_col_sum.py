'''
For a given two-dimensional integer array/list of size (N x M),
you need to find out which row or column has the largest sum(sum of all the elements in a row or column)
amongst all the rows/columns.

'''
from sys import stdin

MIN_VALUE = -2147483648

def findLargest(arr, nRows, mCols):
    # Initializing variables
    isRow = True
    max = MIN_VALUE
    idx = 0
    
    # Loop through rows
    for i in range(nRows):
        rowSum = 0
        # Calculate sum of elements in the current row
        for j in range(mCols):
            rowSum += arr[i][j]
        # Check if the sum is greater than the current largest sum
        if rowSum > max:
            max = rowSum
            idx = i
    
    # Loop through columns
    for j in range(mCols):
        colSum = 0
        # Calculate sum of elements in the current column
        for i in range(nRows):
            colSum += arr[i][j]
        # Check if the sum is greater than the current largest sum
        if colSum > max:
            max = colSum
            idx = j
            isRow = False
    
    # Determine whether the largest sum is in a row or a column and print the result
    if isRow:
        print("row " + str(idx) + " " + str(max))
    else:
        print("column " + str(idx) + " " + str(max))

#Taking Input Using Fast I/O
def take2DInput() :
    li = stdin.readline().rstrip().split(" ")
    nRows = int(li[0])
    mCols = int(li[1])
    
    if nRows == 0 :
        return list(), 0, 0
    
    mat = [list(map(int, input().strip().split(" "))) for row in range(nRows)]
    return mat, nRows, mCols


#main
t = int(stdin.readline().rstrip())

while t > 0 :

    mat, nRows, mCols = take2DInput()
    findLargest(mat, nRows, mCols)

    t -= 1